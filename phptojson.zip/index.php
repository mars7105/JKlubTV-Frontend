<?php
session_start ();
include 'html/htmlstart.html';
include 'lib/jsontotable.php';
include 'html/htmlend.html';

?> 

